## Bootloader fix for TFT35 V2.0 ONLY
*To fix the bootloader on BTT TFT35 V2 to enable firmware update through sd card, flash the 'BIQU_TFT35_V2.0_bootloader.hex' file using the Flymcu application.*

*Follow the instructions provided in the PDF file.*

**You will need a USB to Serial TTL Module (CH340G , Cp2102 or similar)**
**Test with CP2102 module.**