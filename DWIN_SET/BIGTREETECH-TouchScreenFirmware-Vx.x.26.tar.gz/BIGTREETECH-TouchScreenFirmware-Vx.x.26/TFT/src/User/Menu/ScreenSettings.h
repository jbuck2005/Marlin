#ifndef _SCREEN_SETTINGS_H_
#define _SCREEN_SETTINGS_H_

void menuScreenSettings(void);

#endif
