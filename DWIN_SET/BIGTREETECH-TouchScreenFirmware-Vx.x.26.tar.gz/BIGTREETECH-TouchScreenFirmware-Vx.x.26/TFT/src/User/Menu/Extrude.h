#ifndef _EXTRUDE_H_
#define _EXTRUDE_H_

extern const char* tool_change[];
extern const char* extruderDisplayID[];

void menuExtrude(void);

#endif
