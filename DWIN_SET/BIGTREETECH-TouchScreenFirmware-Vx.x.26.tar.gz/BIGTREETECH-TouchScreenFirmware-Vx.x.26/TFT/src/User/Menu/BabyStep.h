#ifndef _BABYSTEP_H_
#define _BABYSTEP_H_

void menuBabyStep(void);
void babyStepReset(void);

#endif
