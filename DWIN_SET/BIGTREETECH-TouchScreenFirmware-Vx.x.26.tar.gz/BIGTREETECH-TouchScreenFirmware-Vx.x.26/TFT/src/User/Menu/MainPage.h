#ifndef _MAINPAGE_H_
#define _MAINPAGE_H_

void menuMain(void);

#endif
