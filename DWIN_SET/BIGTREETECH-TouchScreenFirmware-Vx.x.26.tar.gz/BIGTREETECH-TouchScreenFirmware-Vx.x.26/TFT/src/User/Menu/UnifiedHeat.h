#ifndef _UNIFIEDHEAT_H_
#define _UNIFIEDHEAT_H_

void menuUnifiedHeat(void);

#endif
