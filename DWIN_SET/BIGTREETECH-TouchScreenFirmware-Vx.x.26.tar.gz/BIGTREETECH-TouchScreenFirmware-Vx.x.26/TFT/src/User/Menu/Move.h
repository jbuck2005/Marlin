#ifndef _MOVE_H_
#define _MOVE_H_

void menuMove(void);
void drawXYZ(void);
void update_gantry(void);
#endif
