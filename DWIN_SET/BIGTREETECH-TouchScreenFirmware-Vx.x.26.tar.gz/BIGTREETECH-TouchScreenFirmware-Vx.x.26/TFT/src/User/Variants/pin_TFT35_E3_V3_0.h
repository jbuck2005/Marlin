#ifndef _PIN_TFT35_E3_V3_0_H_ // modify to actual filename !!!
#define _PIN_TFT35_E3_V3_0_H_ // modify to actual filename !!!

// Hardware version config
#ifndef HARDWARE_VERSION
  #define HARDWARE_VERSION "TFT35_E3_V3.0"
#endif

#define LED_COLOR_PIN PC7

#include "pin_TFT35_V3_0.h"

#endif
