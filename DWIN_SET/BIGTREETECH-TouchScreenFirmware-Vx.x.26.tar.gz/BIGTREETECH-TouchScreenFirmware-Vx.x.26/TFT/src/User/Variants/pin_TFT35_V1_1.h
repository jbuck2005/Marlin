#ifndef _PIN_TFT35_V1_1_H_ // modify to actual filename !!!
#define _PIN_TFT35_V1_1_H_ // modify to actual filename !!!

// Hardware version config
#ifndef HARDWARE_VERSION
  #define HARDWARE_VERSION "TFT35_V1.1"
#endif

#include "pin_TFT35_V1_0.h"

#endif
