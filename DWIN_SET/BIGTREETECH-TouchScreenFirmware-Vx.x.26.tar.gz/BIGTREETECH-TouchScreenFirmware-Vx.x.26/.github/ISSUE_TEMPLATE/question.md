---
name: Ask a question
about: Ask a question or request details
title: '[Q] (Your Question?)'
labels: 'question'
assignees: ''

---

**Your question or details you need. Please describe.**
A clear and concise question or detail you would like to ask. Like Hardware related or firmware related.

**specify the device variant related to your question.**

**Additional context**
Add any other context or screenshots about the question here.
