# Firmware installation instructions

Please follow the instructions on the release page in detail. Make sure you have downloaded the correct package! This package contains a "description.txt" which tells you for which hardware configuration this package is.

It explains everything. If you have Creality touch screen - don't forget to flash it according to the instructions. Happy printing!

------

If you're tech savvy - the "configs" directory shows the configuration that has been used for this release. If you don't know what this means, you can ignore this sentence!